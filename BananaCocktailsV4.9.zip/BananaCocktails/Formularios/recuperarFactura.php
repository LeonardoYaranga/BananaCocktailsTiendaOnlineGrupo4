<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Factura</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            width: 50%;
            margin: 50px auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        h2 {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

    <section class="container">
        <h2>Factura</h2>
        <table>
            <tr>
                <th>Nombre</th>
                <td>
                    <?php echo $_POST["nombre"]; ?>
                </td>
            </tr>
            <tr>
                <th>Apellido</th>
                <td>
                    <?php echo $_POST["apellido"]; ?>
                </td>
            </tr>
            <tr>
                <th>Cedula</th>
                <td>
                    <?php echo $_POST["cedula"]; ?>
                </td>
            </tr>
            <tr>
                <th>Email</th>
                <td>
                    <?php echo $_POST["email"]; ?>
                </td>
            </tr>
            <tr>
                <th>Fecha</th>
                <td>
                    <?php echo $_POST["fecha"]; ?>
                </td>
            </tr>
            <tr>
                <th>Dirección</th>
                <td>
                    <?php echo $_POST["direccion"]; ?>
                </td>
            </tr>
        </table>

        <label for="productos">Productos</label>
        <table border=2>
            <tr>
                <th>Producto</th>
                <th>Precio</th>
            </tr>
            <?php
            // Inicializar el total
            $total = 0;

            // Mostrar productos seleccionados
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['productos'], $_POST['precios'])) {
                foreach ($_POST['productos'] as $index => $producto) {
                    echo "<tr>";
                    echo "<td>{$producto}</td>";
                    echo "<td>{$_POST['precios'][$index]} $</td>";

                    // Sumar al total
                    $total += $_POST['precios'][$index];

                    echo "</tr>";
                }
            }

            // Mostrar la fila del total después del bucle
            echo "<tr>";
            echo "<td>Total</td>";
            echo "<td>{$total} $</td>";
            echo "</tr>";
            ?>
        </table>
    </section>

</body>

</html>