<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Pedidos Online | Banana's Cocktails</title>
  <style>
    body {
      background-color: #fff;
      font-family: 'Bahnschrift', Times, serif;
      color: #333;
    }

    header {
      position: fixed;
      top: 0;
      background-image: url('./Images/Iconos/Coctel.jpg');
      background-size: cover;
      background-position: center 43%;
      font-family: 'Monotype Corsiva', Times, serif;
      color: #fff;
      text-align: center;
      padding: 35px;
      border-radius: 10px;
      font-size: 150%;
    }

    nav {
      position: fixed;
      width: 99.2%;
      top: 240px;
      background-color: #333;
      font-family: 'Bahnschrift SemiBold', Times, serif;
      text-align: center;
      border-radius: 10px;
      border-top: 1px solid white;
    }

    .navul {
      padding: 3px;
      list-style-type: none;
    }

    .navli {
      display: inline-block;
      margin-right: 47px;
    }

    .nava {
      text-decoration: none;
      color: #fff;
    }

    .nava:hover {
      color: #fabd50;
    }

    section {
      border-top: 1px solid white;
      border-radius: 10px;
      background-color: #fff;
    }

    footer {
      background-color: #333;
      color: white;
      text-align: center;
      padding: 20px;
      border-top: 1px solid white;
    }

    footer img {
      width: 55px;
      margin: 0 40px;
      padding: 1%;
    }

    h2 {
      text-align: center;
      padding: 20px;
      border-radius: 10px;
      background-color: #ACE3AF;
      color: #333;
      font-family: 'Lucida Calligraphy', Times, serif;
      border-top: 3px solid white;
    }

    .contenedor {
      margin-top: 280px;
    }

    .catalogo {
      min-height: 200vh;
      max-width: 400px;
      margin: 0 auto;
      padding: 0;
      display: flex;
      height: 100vh;
      align-items: center;
      justify-content: center;
    }

    .vodka {
      background-color: #F3EECB;
    }

    .ron {
      background-color: #F3EECB;
    }

    .whisky {
      background-color: #F3EECB;
    }

    .vino {
      background-color: #F3EECB;
    }

    .tequila {
      background-color: #F3EECB;
    }

    .gin {
      background-color: #F3EECB;
    }

    .wrap {
      max-width: 1370px;
      display: flex;
      flex-wrap: nowrap;
      overflow: scroll;
      margin: 0 auto;
      margin-bottom: 60px;
    }

    /*para ponerlos por columnas filas o columnas fijas
     Si usamos scroll en wrap ya no hace tanta falta la clase column-4*/
    .column-4 {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      column-gap: 1rem;
      row-gap: 1rem;
      grid-gap: 20px;
    }

    .tarjeta-rest {
      flex: 1 0 auto;
      margin: 0 1.2rem;
      width: 300px;
      background-repeat: no-repeat;
      height: 380px;
      border-radius: 6px;
      padding: 1rem .5rem;
      display: flex;
      align-items: end;

    }

    .wrap-text_tarjeta-rest {
      color: #fff;
      padding: .5rem;
      border-radius: 6px;
      background: linear-gradient(to top, rgb(0 0 0 /.5), rgb(0 0 0 /.5));
    }

    .wrap-text_tarjeta-rest p {
      color: #FFFFDA;

    }

    .cta-wrap_tarjeta-rest {
      display: flex;
      justify-content: space-between;
    }

    .precio_tarjeta-rest span {
      font-size: 1.5rem;
      font-weight: bold;
      color: #333;
    }

    .cta_tarjeta-rest {
      background-color: #FFC300;
      padding: .25 rem 1 rem;
      border-radius: 4px;
    }

    .cta_tarjeta-rest a {
      color: #fff;
      font-weight: bold;
    }

    .cta_tarjeta-rest input {
      background-color: #FFC300;
      padding: .25 rem 1 rem;
      border-radius: 4px;
      color: #fff;
      font-weight: bold;
    }

    img {
      width: 300px;
      height: auto;
    }

    .text {
      color: #fff;
      font-family: 'Broadway', Times, serif;
      text-decoration: none;
      font-size: 24px;
    }

    .text:hover {
      background: linear-gradient(to top, rgb(0 0 0 /.5), rgb(0 0 0 /.5));
      border-radius: 20%;
      color: #F5CBB9;
      padding: 5%;
    }

    aside {
      height: 100%;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      right: 0;
      background-color: #f1f1f1;
      overflow-x: hidden;
      transition: 0.5s;
      padding-top: 60px;
    }

    aside a {
      padding: 8px 8px 8px 32px;
      text-decoration: none;
      font-size: 25px;
      color: #818181;
      display: block;
      transition: 0.3s;
    }

    aside a:hover {
      color: #f1f1f1;
    }

    aside .closebtn {
      position: absolute;
      top: 0;
      right: 25px;
      font-size: 25px;
      margin-left: 50px;
      background-color: #FF9999;
    }

    /* Estilos para la imagen del carrito */
    #carritoImagen {
      cursor: pointer;
      transition: transform 0.3s;
    }

    #carritoImagen:hover {
      transform: scale(1.1);
    }

    .aside-content table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background-color: #D4F4DB; 
    font-family: 'Bahnschrift SemiBold', Times, serif;
  }

  .aside-content form input[type="submit"] {
    background-color: #F8A666; 
    color: white; 
    padding: 20px; 
    margin-top: 7px; 
    border: none;
    border-radius: 10px; 
    cursor: pointer; 
    font-size: 16px;
  }

  .aside-content {
    padding: 20px;
  }
  </style>
</head>

<?php

// Inicializar el arreglo de productos seleccionados
if (!isset($_SESSION['productos_seleccionados'])) {
  $_SESSION['productos_seleccionados'] = [];
}

// Verificar si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['producto'], $_POST['precio'])) {
    // Agregar el nuevo producto al arreglo
    $_SESSION['productos_seleccionados'][] = [
      'producto' => $_POST['producto'],
      'precio' => $_POST['precio']
    ];
  } elseif (isset($_POST['borrar_ultimo'])) {
    // Borrar el último producto si se envió el formulario para borrar
    array_pop($_SESSION['productos_seleccionados']);
  } elseif (isset($_POST['vaciar_lista'])) {
    // Vaciar toda la lista si se envió el formulario para vaciar
    $_SESSION['productos_seleccionados'] = [];
  }
}
?>

<body>
  <header>

    <table>

      <tr>
        <td style="width:5%">
          <img src="./Images/Iconos/Logotipo.png" alt="Logotipo" style="width:250%;">
        </td>
        <td style="width:25%">
          <a href=" #" class="text">Inicio</a>
        </td>
        <td style="text-align: center; width:30%">
          <h1>Banana's Cocktails</h1>
          <p><em>¡Cócteles exclusivos a un clic de distancia!</em></p>
        </td>
        <td style="width:30%">

          <?php
          if (!empty($_GET["name"])) {
            $nameUser = $_GET["name"];
            echo '<h3>Hola ' . $nameUser . '</h3>';
          } else {
            echo '<a href="./Formularios/login.php" class="text">Iniciar sesión</a>';
          }
          ?>

        </td>
        <td style="width:5%">
          <img src="./Images/Iconos/CarritoCompra.png" alt="Imagen de Carrito de Compras" style="width:130%;"
            id="carritoImagen" onclick="openAside()">
        </td>
      </tr>
    </table>

  </header>
  <nav class="navul">
    <ul>
      <strong>
        <li class="navli"><a href="#vodkaRef" class="nava">Vodka</a></li>
        <li class="navli"><a href="#ronRef" class="nava">Ron</a></li>
        <li class="navli"><a href="#tequilaRef" class="nava">Tequila</a></li>
        <li class="navli"><a href="#whiskyRef" class="nava">Whisky</a></li>
        <li class="navli"><a href="#ginRef" class="nava">Gin</a></li>
        <li class="navli"><a href="#vinoRef" class="nava">Vino</a></li>
      </strong>
    </ul>
  </nav>

  <section class="contenedor">

    <section class="Catalogo">

      <!-- Mostrar productos seleccionados -->
      <aside id="popup">

        <button class="closebtn" onclick="closeAside()">Cerrar</button>
        <section class="aside-content">

          <article class="inputBox" id="productos-seleccionados">
            <label for="productos">Productos Seleccionados</label>
            <table border=2>
              <tr>
                <th>
                  Producto
                </th>
                <th>
                  Precio
                </th>
              </tr>
              <?php
              // Iterar sobre los productos seleccionados y mostrarlos en la tabla
              foreach ($_SESSION['productos_seleccionados'] as $producto) {
                echo "<tr>";
                echo "<td>{$producto['producto']}</td>";
                echo "<td>{$producto['precio']} $</td>";
                echo "</tr>";
              }
              ?>
            </table>
          </article>

          <!-- Formulario para finalizar la compra -->
          <form action="./Formularios/factura.php" method="post" target=" _blank">
            <?php
            // Agregar campos ocultos para todos los productos seleccionados
            foreach ($_SESSION['productos_seleccionados'] as $producto) {
              echo '<input type="hidden" name="productos[]" value="' . $producto['producto'] . '">';
              echo '<input type="hidden" name="precios[]" value="' . $producto['precio'] . '">';
            }
            ?>
            <input type="submit" value="Finalizar Compra">
          </form>

          <!-- Formulario para borrar el último producto -->
          <form action="index.php" method="post">
            <input type="submit" name="borrar_ultimo" value="Borrar Último Producto">
          </form>

          <!-- Formulario para vaciar la lista -->
          <form action="index.php" method="post">
            <input type="submit" name="vaciar_lista" value="Vaciar Lista">
          </form>
        </section>
      </aside>

      <h2 id="vodkaRef">Vodka</h2>
      <section class="wrap columns vodka">
        <article class="tarjeta-rest"
          style="background: url(./Images/Vodka/VodkaTonic.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Vodka Tonic</h3>
            <p>El Vodka Tonic es una bebida refrescante que mezcla vodka con agua tónica, destacando por su simplicidad y equilibrio.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 9$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <form method="post">
                  <input type="hidden" name="producto" value="Vodka Tonic">
                  <input type="hidden" name="precio" value="9">
                  <input type="submit" value="Comprar">
                </form>
              </article>
            </section>

          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Vodka/Caipiroska.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Caipiroska</h3>
            <p>La Caipiroska es una versión deliciosa y refrescante de la Caipirinha, utilizando vodka, con lima, azúcar y hielo.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 10$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <form method="post">
                  <input type="hidden" name="producto" value="Caipiroska">
                  <input type="hidden" name="precio" value="10">
                  <input type="submit" value="Comprar">
              </article>
            </section>
          </section>
        </article>


        <article class="tarjeta-rest"
          style="background: url(./Images/Vodka/Cosmopolitan.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Cosmopolitan</h3>
            <p>El Cosmopolitan es un cóctel clásico que combina vodka, triple sec, arándano y jugo de limón, creando una bebida elegante y equilibrada.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 9$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Vodka/Destornillador.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Destornillador</h3>
            <p>El Destornillador es un cóctel sencillo que mezcla vodka con jugo de naranja, ofreciendo una bebida refrescante y fácil de disfrutar.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 10$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Vodka/SexOnTheBeach.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Sex on the Beach</h3>
            <p>Sex on the Beach es un cóctel tropical que combina vodka, licor de durazno, jugo de arándano y jugo de naranja, creando una bebida colorida y sabrosa con un toque frutal.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 9$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>
        <article class="tarjeta-rest"
          style="background: url(./Images/Vodka/VodkaSunrise.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Vodka sunrise</h3>
            <p>El Vodka Sunrise es una mezcla de vodka, jugo de naranja y grenadina, creando un cóctel colorido y refrescante.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 13$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>


      </section>

      <h2 id="ronRef">Ron</h2>
      <section class="wrap columns ron">
        <article class="tarjeta-rest"
          style="background: url(./Images/Ron/Caipirinha.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Caipirinha</h3>
            <p>La Caipirinha es un cóctel brasileño clásico que combina cachaça, azúcar y lima, creando una bebida refrescante y ligeramente dulce.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 7$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Ron/Corazonada.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Corazonada</h3>
            <p>Corazonada es un cóctel con base de ron añejo, anís, sirope de fresa y zumo de fresa, de limón y de naranja. </p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 7$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Ron/CubaLibre.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Cuba libre</h3>
            <p>El "Cuba Libre" es un cóctel clásico que generalmente se prepara con ron, cola y limón. </p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 10$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Ron/DaikiriClasico.jpeg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Daikiri clasico</h3>
            <p>El Daiquiri clásico es un cóctel refrescante compuesto por ron blanco, azúcar y jugo de limón. </p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 7$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Ron/MojitoClasico.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Mojito clasico</h3>
            <p>El Mojito clásico es un cóctel cubano que combina ron blanco, azúcar, jugo de limón, menta y soda.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 7$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Ron/MojitoFrutilla.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Mojito frutilla</h3>
            <p>El Mojito de fresa es una variante del clásico cóctel cubano que incorpora fresas frescas a la mezcla tradicional de ron blanco, azúcar, jugo de limón, menta y soda.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 15$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Ron/PiñaColada.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Piña colada</h3>
            <p>La Piña Colada es un cóctel tropical que combina ron blanco, crema de coco y jugo de piña.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 5$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest" style="background: url(./Images/Ron/Pitufo.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Pitufo</h3>
            <p>Este cóctel suele estar compuesto por ron, curaçao azul, jugo de limón o lima, y azúcar o jarabe.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 12$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>



      </section>

      <h2 id="tequilaRef">Tequila</h2>
      <section class="wrap columns tequila">
        <article class="tarjeta-rest"
          style="background: url(./Images/Tequila/MargaritaBlue.jpeg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Margarita blue</h3>
            <p>La Margarita Blue es una variante fresca y colorida del clásico cóctel Margarita, con tequila, licor de naranja, jugo de lima y curaçao azul.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 10$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Tequila/MargaritaClasico.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Margarita clasico</h3>
            <p>La Margarita clásica es una mezcla refrescante de tequila, triple sec y jugo de lima, servida en un vaso escarchado con sal.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 10$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Tequila/MargaritaFrutilla.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Margarita frutilla</h3>
            <p>La Margarita de fresa combina tequila, licor de naranja, puré de fresas y jugo de lima, creando una variante dulce y refrescante del clásico.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 16$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Tequila/Martini.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Martini</h3>
            <p>El Martini es un elegante cóctel que generalmente se elabora con ginebra y vermut seco, decorado con una aceituna o piel de limón.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 10$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Tequila/MartiniFrutilla.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Martini frutilla</h3>
            <p>El Martini de fresa es una versión afrutada del clásico Martini, destacando por su toque dulce y refrescante con la adición de puré o licor de fresa.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 11$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>



        <article class="tarjeta-rest"
          style="background: url(./Images/Tequila/TequilaSunrise.jpeg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Tequila sunrise</h3>
            <p>El Tequila Sunrise es un cóctel refrescante con tequila, jugo de naranja y un toque de grenadina, destacando por su atractiva apariencia degradada.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 10$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

      </section>

      <h2 id="whiskyRef">Whisky</h2>
      <section class=" wrap columns whisky">
        <article class="tarjeta-rest"
          style="background: url(./Images/Whisky/Padrino.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Padrino</h3>
            <p>El Padrino es un cóctel clásico que combina whisky y amaretto para crear una mezcla equilibrada y suave.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 6$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Whisky/WhiskyOnTheRocks.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Whisky on the Rocks</h3>
            <p>Whisky on the Rocks es un cóctel simple y clásico que consiste en servir whisky directamente sobre hielo.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 12$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>



      </section>

      <h2 id="ginRef">Gin</h2>
      <section class="wrap columns gin">
        <article class="tarjeta-rest"
          style="background: url(./Images/Gin/GinTonic.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Gin tonic</h3>
            <p>Gin Tonic es un refrescante cóctel que combina ginebra y agua tónica, servido sobre hielo y adornado con rodajas de limón o enebro.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 16$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Gin/GinTonicFrutosRojos.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Gin Tonic Frutos Rojos</h3>
            <p>Gin Tonic de frutos rojos es una variante del clásico cóctel, que incorpora ginebra, agua tónica y una mezcla de frutos rojos para un toque fresco y afrutado.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 16$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

      </section>

      <h2 id="vinoRef">Vino</h2>
      <section class="wrap columns vino">
        <article class="tarjeta-rest"
          style="background: url(./Images/Vino/Sangria.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Sangria</h3>
            <p>La sangría es una bebida española a base de vino tinto y frutas, ideal para disfrutar en compañía.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 16$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

        <article class="tarjeta-rest"
          style="background: url(./Images/Vino/TintoDeVerano.jpg) center; background-size: cover;">
          <section class="wrap-text_tarjeta-rest">
            <h3>Tinto de verano</h3>
            <p>El tinto de verano es una refrescante bebida española elaborada con vino tinto y soda, perfecta para días calurosos.</p>

            <section class="cta-wrap_tarjeta-rest">
              <article class="precio_tarjeta-rest">
                <span> 16$</span>

              </article>
              <article class="cta_tarjeta-rest">
                <a href="#">Comprar</a>
              </article>
            </section>
          </section>
        </article>

      </section>

    </section>

  </section>

  <footer>
    <img src="./Images/Iconos/instagram.png" alt="Instagram"
      onclick="window.open('https://www.instagram.com/', '_blank')">
    <img src="./Images/Iconos/facebook.png" alt="Facebook" onclick="window.open('https://www.facebook.com/', '_blank')">
    <img src="./Images/Iconos/tiktok.png" alt="TikTok" onclick="window.open('https://www.tiktok.com/', '_blank')">
    <p>&copy;2023 Banana's Cocktails</p>
  </footer>

  <button onclick="openAside()">Mostrar Código PHP</button>

  <script>
    function openAside() {
      document.getElementById("popup").style.width = "30%";
    }

    function closeAside() {
      document.getElementById("popup").style.width = "0%";
    }
  </script>

</body>

</html>