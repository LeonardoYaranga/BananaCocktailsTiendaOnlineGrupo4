<?php
session_start();

// Verificar si se ha enviado un formulario de compra
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['producto'], $_POST['precio'])) {
    $producto = $_POST['producto'];
    $precio = floatval($_POST['precio']);

    // Inicializar la sesión del carrito si no existe
    if (!isset($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }

    // Agregar el producto al carrito
    $_SESSION['carrito'][] = ['producto' => $producto, 'precio' => $precio];
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <title>Facturación</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        * {
            font-family: 'Lucida Calligraphy', Times, serif;
        }

        body {
            max-width: 800px;
            background-color: #fff;
            margin: 0 auto;
            justify-content: center;
            align-items: center;
        }

        header {
            align-content: center;
            color: #fff;
            background-color: #9a619d;
            border-radius: 20px;
            min-height: 70px;
            background-image: url(img/DiscreteOldfashionedGalapagostortoise-max-1mb.gif);
            width: 100%;
            height: 200px;
            opacity: 70%;
            padding: 0cm;
            position: sticky;
            /*POSICION MODIFICADA*/

        }

        header h1 {
            text-align: center;
            padding: 4rem;
            font-size: 80px;
            margin-bottom: 10px;
            text-shadow: 10px 8px 5px black;

        }

        nav {
            background-color: #fabd50;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            display: inline-block;
        }

        nav ul li {
            float: left;
            margin-top: 20px;
        }

        nav ul li a {
            color: white;
            font-weight: bold;
            text-decoration: none;
            font-size: 20px;
            padding: 20px;
        }

        nav a:hover {
            background-color: blue;
            color: yellow;
            font-weight: bold;
        }

        section {
            background-color: #16ab9d;
            width: 100%;

        }


        footer {
            background-color: #333;
            padding: 40px;
            text-align: center;
            padding: 0px;

        }

        footer p {
            font-size: 20px;
            font-weight: bold;
            padding: 20px;
            background-color: skyblue;
        }

        .container {

            max-width: 750px;
            background: #16ab9d;
            width: 100%;
            padding: 25px 25px;
            border-radius: 5px;
        }

        .container form {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        form label {
            font-size: 25px;
        }

        form .inputBox {
            margin: 20px 0 12px 0;
            width: calc(100%/2 - 20px);
        }

        .container .inputBox input,
        textarea {
            max-width: 100%;
            min-width: 100%;
            min-height: 45px;
            max-height: 150px;
            height: 45px;
            width: 100%;
            outline: none;
            border-radius: 15px;
            border: 1px solid rgb(161, 17, 17);
            padding-left: 10px;
            font-size: 15px;
            border-bottom-width: 2px;
        }

        .inputBox input:focus,
        .inputBox input:valid {
            border-color: red;
        }

        form .button {
            height: 25px;
            margin: 25px 0;
        }

        form .button button {
            height: 200%;
            width: 370%;
            outline: none;
            color: white;
            font-size: 20px;
            font-weight: 500;
            border: none;
            background: #9a619d;
            border-radius: 5px;
            letter-spacing: 1px;
        }

        form .button button:hover {
            background-color: blueviolet;
        }

        aside {
            background-color: blue;
            float: right;
            width: 50%;
        }

        img {
            width: 50%;
        }
    </style>

</head>

<body>

    <header>
        <h1> Facturación </h1>
    </header>

    <nav>
        <ul>
            <li><a href="#">Inicio</a> </li>
            <li><a href="#">Cocteles</a> </li>
            <li><a href="#">Contactanos</a> </li>
        </ul>
    </nav>

    <section class="container">

        <p>Para realizar una reserva, por favor llena el siguiente formulario con todos tus datos y nos contactaremos
            con usted a la brevedad posible para confirmarla.
            * Todas las reservas serán validadas por vía telefónica.
        </p>

        <form action="../Formularios/recuperarFactura.php" method="post" target="_blank">
            <article class="inputBox">
                <label for="nombre">Nombre</label>
                <input id="nombre" name="nombre" placeholder="Ingresa tu nombre" required />
            </article>

            <article class="inputBox">
                <label for="apellido">Apellido</label>
                <input id="apellido" name="apellido" placeholder="Ingresa tu apellido" required />
            </article>

            <article class="inputBox">
                <label for="id">Numero de cedula</label>
                <input id="cedula" name="cedula" placeholder="Ingresa tu número  de cedula" required />
            </article>

            <article class="inputBox">
                <label for="celular">Celular</label>
                <input type="text" name="celular" id="celular" placeholder="Ingresa tu número  de celular" required />
            </article>

            <article class="inputBox">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" placeholder="Ingresa tu email" required />
            </article>

            <article class="inputBox">
                <label for="fecha">Fecha</label>
                <input type="date" name="fecha" id="fecha" required />
            </article>


            <article class="inputBox">
                <label for="productos">Productos</label>
                <table border=2>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                    </tr>
                    <?php
                    // Mostrar productos seleccionados
                    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['productos'], $_POST['precios'])) {
                        foreach ($_POST['productos'] as $index => $producto) {
                            echo "<tr>";
                            echo "<td>{$producto}</td>";
                            echo "<td>{$_POST['precios'][$index]} $</td>";
                            // Campos ocultos para cada producto y precio con input para que se recuperar datos
                            echo "<input type='hidden' name='productos[]' value='{$producto}'>";
                            echo "<input type='hidden' name='precios[]' value='{$_POST['precios'][$index]}'>";
                            echo "</tr>";
                        }
                    }
                    ?>
                </table>
            </article>

            <article class="inputBox">
                <label for="comentario"> Comentarios </label>
                <br>
                <textarea cols="35" rows="7" id="comentario" name="comentario"> </textarea>
            </article>


            <article class="button">
                <button type="submit" value="reserva"> Solicitar reserva </button>
            </article>

        </form>

    </section>



    <footer>
        <p> © Copyright 2023 SheyleeBar Derechos reservados</p>

    </footer>


</body>

</html>